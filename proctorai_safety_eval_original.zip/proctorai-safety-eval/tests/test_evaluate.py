import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from evaluate import evaluate, load_records, stats

class EvaluationTests(unittest.TestCase):
    def test_counts(self):
        rows=[{'actual':1,'predicted':1},{'actual':0,'predicted':1},
              {'actual':0,'predicted':0},{'actual':1,'predicted':0}]
        s=stats(rows)
        self.assertEqual((s['tp'],s['fp'],s['tn'],s['fn']),(1,1,1,1))
        self.assertEqual(s['false_positive_rate'],0.5)
    def test_empty_positive_denominator(self):
        self.assertIsNone(stats([{'actual':0,'predicted':0}])['recall'])
    def test_synthetic_data(self):
        path=Path(__file__).resolve().parents[1]/'data'/'synthetic_events.csv'
        report=evaluate(load_records(path))
        self.assertEqual(report['overall']['events'],12)
        self.assertIn('dim', report['by_condition']['lighting'])
        self.assertTrue(report['requires_human_review_for_all_positive_flags'])
        self.assertIn('E002', report['low_confidence_positive_event_ids'])
    def test_bad_threshold(self):
        with self.assertRaises(ValueError):
            evaluate([],1.5)

if __name__=='__main__':
    unittest.main()
