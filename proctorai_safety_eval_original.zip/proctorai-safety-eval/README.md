# Proctoring AI: Safety & Reliability Evaluation

**Original evaluation toolkit** for examining false-positive alerts, missed violations, and sensitivity to environmental conditions in proctoring systems.

This repository is **not a copy of ProctorAI's implementation** and is **not evidence of independent authorship of that original system**. The existing [ProctorAI project](https://github.com/braviaprime/proctorai) is third-party work. This evaluation repo does not bundle its code, trained models, dataset, or assets.

## Research question

How reliably do binary proctoring alerts behave across changes in lighting and background noise, and how should uncertain alerts be routed for human review instead of being treated as automatic misconduct findings?

## What the code does

- Computes accuracy, precision, recall, false-positive and false-negative rates.
- Breaks error rates out by lighting and noise categories.
- Identifies lower-confidence positive alerts for additional review.
- Enforces data validation and includes automated tests.
- Does **not** use raw faces, voices, audio, or video; inputs are event-level labels.

## Quick start

Python 3.9+; no third-party dependencies.

```bash
python src/evaluate.py data/synthetic_events.csv --output report.json
python -m unittest discover -s tests -v
```

## Dataset format

CSV fields: `event_id,ground_truth_violation,predicted_violation,confidence,lighting,noise`.

Only use consented, de-identified, documented data with appropriately determined ground-truth labels. Synthetic examples in `data/` are **illustrative**, not evidence of model accuracy, real-world performance, fairness, or robustness.

## Safety limitations

- Anomalous gaze, background speech, or changes in lighting do **not** prove dishonesty.
- False positives can seriously harm examinees; a human should review any alert before action.
- This is a reporting tool, **not** an independent AI model or mechanistic interpretability study.
- Comparing error rates across lighting/noise conditions is a limited robustness check, **not** a demographic fairness audit.
- Uncertainty scores are only meaningful if the upstream model's confidence is calibrated.

## Suggested original experiment

1. Obtain authorization to test an existing proctoring implementation.
2. Define a ground-truth annotation protocol and avoid ambiguous guilt-based labels.
3. Generate a balanced, consented test set for bright/dim conditions and quiet/noisy conditions.
4. Export event-level predictions (without recording or publishing biometrics).
5. Run this evaluator, report support counts, uncertainty, and error rates.
6. Document ethics, limitations, reproducible protocol, and results honestly.

## Authorship and provenance

This evaluation code was prepared as a new standalone research starter. The user must independently run, understand, test, and adapt it before claiming research contributions or performance results on a CV. It does not reproduce any source code from `braviaprime/proctorai`.
