"""Independent safety evaluation for binary monitoring alerts.

No video, audio, face biometrics, or source project code is included.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

REQUIRED = ('event_id','ground_truth_violation','predicted_violation','confidence','lighting','noise')


def load_records(path: Path) -> list[dict]:
    with path.open(newline='', encoding='utf-8') as stream:
        reader = csv.DictReader(stream)
        if not set(REQUIRED).issubset(reader.fieldnames or []):
            raise ValueError('CSV must include: ' + ', '.join(REQUIRED))
        rows = []
        for line, raw in enumerate(reader, start=2):
            try:
                actual = int(raw['ground_truth_violation'])
                predicted = int(raw['predicted_violation'])
                conf = float(raw['confidence'])
                if actual not in (0,1) or predicted not in (0,1) or not 0 <= conf <= 1:
                    raise ValueError('invalid value range')
            except (ValueError, TypeError) as exc:
                raise ValueError(f'Invalid label or confidence at line {line}') from exc
            rows.append({**raw, 'actual':actual, 'predicted':predicted, 'confidence_value':conf})
    if not rows:
        raise ValueError('Dataset has no events')
    if len({r['event_id'] for r in rows}) != len(rows):
        raise ValueError('Duplicate event_id')
    return rows


def stats(rows: list[dict]) -> dict:
    tp = sum(r['actual']==1 and r['predicted']==1 for r in rows)
    tn = sum(r['actual']==0 and r['predicted']==0 for r in rows)
    fp = sum(r['actual']==0 and r['predicted']==1 for r in rows)
    fn = sum(r['actual']==1 and r['predicted']==0 for r in rows)
    div = lambda n, d: round(n/d, 4) if d else None
    return {
        'events':len(rows),'tp':tp,'tn':tn,'fp':fp,'fn':fn,
        'precision':div(tp,tp+fp),
        'recall':div(tp,tp+fn),
        'false_positive_rate':div(fp,fp+tn),
        'false_negative_rate':div(fn,fn+tp),
        'accuracy':div(tp+tn,len(rows)),
    }


def evaluate(rows: list[dict], review_threshold: float=0.7) -> dict:
    if not 0 <= review_threshold <= 1:
        raise ValueError('review threshold must be 0..1')
    groups = {}
    for field in ('lighting','noise'):
        by = defaultdict(list)
        for r in rows:
            by[r[field]].append(r)
        groups[field] = {name:stats(chunk) for name,chunk in sorted(by.items())}
    # Even high-confidence detections are alerts, never automatic misconduct verdicts.
    return {
        'dataset_note':'Results describe only the supplied labelled events, not real-world model performance.',
        'overall':stats(rows),
        'by_condition':groups,
        'requires_human_review_for_all_positive_flags':True,
        'low_confidence_positive_event_ids':[
            r['event_id'] for r in rows if r['predicted'] and r['confidence_value'] < review_threshold
        ],
        'review_threshold':review_threshold,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description='Evaluate safety and reliability of proctoring alerts')
    parser.add_argument('csv_path',type=Path)
    parser.add_argument('--review-threshold',type=float,default=0.7)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    report=evaluate(load_records(args.csv_path),args.review_threshold)
    output=json.dumps(report,indent=2)
    if args.output:
        args.output.write_text(output+'\n',encoding='utf-8')
        print(f'Wrote {args.output}')
    else:
        print(output)

if __name__=='__main__':
    main()
